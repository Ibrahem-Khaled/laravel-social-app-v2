

<?php $__env->startSection('content'); ?>
    <div class="container mt-4 text-right">
        <h1>إدارة الهدايا</h1>

        <!-- قسم الإحصائيات -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white text-center">
                    <div class="card-body">
                        <h3><?php echo e($totalGifts); ?></h3>
                        <p>إجمالي الهدايا</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white text-center">
                    <div class="card-body">
                        <h3><?php echo e($activeGifts); ?></h3>
                        <p>الهدايا النشطة</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-dark text-center">
                    <div class="card-body">
                        <h3><?php echo e($inactiveGifts); ?></h3>
                        <p>الهدايا غير النشطة</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white text-center">
                    <div class="card-body">
                        <h3><?php echo e(number_format($averagePrice, 2)); ?></h3>
                        <p>متوسط سعر الهدايا</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-body">
                        <h5>أغلى هدية</h5>
                        <h4><?php echo e($highestPricedGift->title ?? 'غير متوفرة'); ?></h4>
                        <p class="text-muted"><?php echo e($highestPricedGift->price ?? 'غير متوفرة'); ?> نقطة</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-body">
                        <h5>أرخص هدية</h5>
                        <h4><?php echo e($lowestPricedGift->title ?? 'غير متوفرة'); ?></h4>
                        <p class="text-muted"><?php echo e($lowestPricedGift->price ?? 'غير متوفرة'); ?> نقطة</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- البحث -->
        <form action="<?php echo e(route('gifts.index')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="ابحث عن هدية"
                    value="<?php echo e(request('search')); ?>">
                <button type="submit" class="btn btn-primary">بحث</button>
            </div>
        </form>
        <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#addGiftModal">إضافة هدية جديدة</button>

        <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- جدول الهدايا -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>المعرف</th>
                    <th>العنوان</th>
                    <th>الوصف</th>
                    <th>السعر</th>
                    <th>الصورة</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $gifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($gift->id); ?></td>
                        <td><?php echo e($gift->title); ?></td>
                        <td><?php echo e(Str::limit($gift->description, 50)); ?></td>
                        <td><?php echo e($gift->price); ?> نقطة</td>
                        <td><img src="<?php echo e(asset('storage/' . $gift->image)); ?>" alt="Gift Image" width="50" height="50"></td>
                        <td><?php echo e($gift->is_active ? 'نشطة' : 'غير نشطة'); ?></td>
                        <td>
                            <button class="btn btn-success" data-toggle="modal"
                                data-target="#editGiftModal<?php echo e($gift->id); ?>">تعديل</button>
                            <form action="<?php echo e(route('gifts.destroy', $gift)); ?>" method="POST"
                                style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" onclick="return confirm('هل أنت متأكد؟')">حذف</button>
                            </form>
                        </td>
                    </tr>

                    <!-- Edit Gift Modal -->
                    <div class="modal fade" id="editGiftModal<?php echo e($gift->id); ?>" tabindex="-1"
                        aria-labelledby="editGiftModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <?php echo $__env->make('dashboard.gifts.form', ['gift' => $gift], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">لا توجد هدايا</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3">
            <?php echo e($gifts->links()); ?>

        </div>
    </div>

    <!-- Add Gift Modal -->
    <div class="modal fade" id="addGiftModal" tabindex="-1" aria-labelledby="addGiftModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <?php echo $__env->make('dashboard.gifts.form', ['gift' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/gifts/index.blade.php ENDPATH**/ ?>