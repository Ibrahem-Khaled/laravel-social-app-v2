<form action="<?php echo e($user ? route('users.update', $user->id) : route('users.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if($user): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="modal-header">
        <h5 class="modal-title"><?php echo e($user ? 'تعديل بيانات المستخدم' : 'إضافة مستخدم جديد'); ?></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <div class="mb-3">
            <label for="username" class="form-label">اسم المستخدم</label>
            <input type="text" name="username" class="form-control" value="<?php echo e($user->username ?? ''); ?>" required>
        </div>
        <div class="mb-3">
            <label for="name" class="form-label">الاسم</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($user->name ?? ''); ?>" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">البريد الإلكتروني</label>
            <input type="email" name="email" class="form-control" value="<?php echo e($user->email ?? ''); ?>" required>
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">رقم الهاتف</label>
            <input type="text" name="phone" class="form-control" value="<?php echo e($user->phone ?? ''); ?>" required>
        </div>
        <?php if(!$user): ?>
            <div class="mb-3">
                <label for="password" class="form-label">كلمة المرور</label>
                <input type="password" name="password" class="form-control" required>
            </div>
        <?php endif; ?>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-primary"><?php echo e($user ? 'حفظ التعديلات' : 'إضافة'); ?></button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
    </div>
</form>
<?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/users/form.blade.php ENDPATH**/ ?>