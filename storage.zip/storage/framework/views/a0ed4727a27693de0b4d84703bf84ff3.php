

<?php $__env->startSection('content'); ?>
    <div class="container mt-4 text-right">
        <h1>الرسائل</h1>
        <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- إحصائيات -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <i class="fas fa-envelope fa-3x text-primary mb-3"></i>
                        <h3><?php echo e($totalMessages); ?></h3>
                        <p>إجمالي الرسائل</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <i class="fas fa-envelope-open-text fa-3x text-success mb-3"></i>
                        <h3><?php echo e($readMessages); ?></h3>
                        <p>الرسائل المقروءة</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <i class="fas fa-envelope fa-3x text-danger mb-3"></i>
                        <h3><?php echo e($unreadMessages); ?></h3>
                        <p>الرسائل غير المقروءة</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <i class="fas fa-users fa-3x text-info mb-3"></i>
                        <h3><?php echo e($anonymousMessages); ?></h3>
                        <p>الرسائل المجهولة</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- زر فتح المودال -->
        <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#sendMessageModal">إرسال رسالة جديدة</button>

        <!-- Modal لإرسال الرسائل -->
        <div class="modal fade" id="sendMessageModal" tabindex="-1" aria-labelledby="sendMessageModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <?php echo $__env->make('dashboard.messages.form', ['message' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>

        <!-- جدول الرسائل -->
        <form action="<?php echo e(route('messages.deleteMultiple')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll"></th>
                        <th>المرسل</th>
                        <th>المستلم</th>
                        <th>الرسالة</th>
                        <th>الحالة</th>
                        <th>تاريخ الإرسال</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="message_ids[]" value="<?php echo e($message->id); ?>">
                            </td>
                            <td><?php echo e($message->is_anonymous ? 'مجهول' : $message->sender->name); ?></td>
                            <td><?php echo e($message->receiver->name); ?></td>
                            <td><?php echo e($message->message); ?></td>
                            <td>
                                <?php if($message->is_read): ?>
                                    <i class="fas fa-envelope-open text-success" title="مقروءة"></i> مقروءة
                                <?php else: ?>
                                    <i class="fas fa-envelope text-danger" title="غير مقروءة"></i> غير مقروءة
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($message->created_at->diffForHumans()); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">لا توجد رسائل</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if($messages->count() > 0): ?>
                <button type="submit" class="btn btn-danger mt-3"
                    onclick="return confirm('هل أنت متأكد من حذف الرسائل المحددة؟')">
                    حذف الرسائل المحددة
                </button>
            <?php endif; ?>
        </form>

        <div class="mt-3">
            <?php echo e($messages->links()); ?>

        </div>
    </div>

    <script>
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('input[name="message_ids[]"]');
            checkboxes.forEach(checkbox => checkbox.checked = this.checked);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/messages/index.blade.php ENDPATH**/ ?>