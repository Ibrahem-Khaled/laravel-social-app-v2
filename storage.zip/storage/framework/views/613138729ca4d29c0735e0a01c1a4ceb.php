

<?php $__env->startSection('content'); ?>
    <div class="container mt-4 text-right">
        <h1>إدارة المنشورات</h1>

        <!-- الإحصائيات -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">إجمالي المنشورات</h5>
                        <p class="card-text"><?php echo e($totalPosts); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">المنشورات بدون وسائط</h5>
                        <p class="card-text"><?php echo e($postsWithoutMedia); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">المنشورات وسائط فقط</h5>
                        <p class="card-text"><?php echo e($postsMediaOnly); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mt-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">المنشورات وسائط ومحتوى</h5>
                        <p class="card-text"><?php echo e($postsMediaAndContent); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mt-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">المنشورات المثبتة</h5>
                        <p class="card-text"><?php echo e($pinnedPosts); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mt-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">المنشورات النشطة</h5>
                        <p class="card-text"><?php echo e($activePosts); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- البحث والمنشورات -->
        <form action="<?php echo e(route('posts.index')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="ابحث عن منشور أو مستخدم"
                    value="<?php echo e(request('search')); ?>">
                <select name="status" class="form-control">
                    <option value="">كل الحالات</option>
                    <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>نشط</option>
                    <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>غير نشط</option>
                    <option value="banned" <?php echo e(request('status') == 'banned' ? 'selected' : ''); ?>>محظور</option>
                </select>
                <button type="submit" class="btn btn-primary">بحث</button>
            </div>
        </form>

        <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#addPostModal">إضافة منشور جديد</button>

        <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- جدول المنشورات -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>المعرف</th>
                    <th>المستخدم</th>
                    <th>المحتوى</th>
                    <th>الصور</th>
                    <th>الحالة</th>
                    <th>مثبت</th>
                    <th>التاريخ</th>
                    <th>البلاغات</th>
                    <th>التعليقات</th>
                    <th>الإعجابات</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($post->id); ?></td>
                        <td><?php echo e($post->user->name); ?></td>
                        <td><?php echo e(Str::limit($post->content, 50)); ?></td>
                        <td>
                            <?php if($post->images): ?>
                                <?php $__currentLoopData = json_decode($post->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset('storage/' . $image)); ?>" width="100" alt="Post Image" class="img-thumbnail" >
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </td>
                        <td><?php echo e($post->status); ?></td>
                        <td><?php echo e($post->pinned ? 'نعم' : 'لا'); ?></td>
                        <td>
                            <small class="text-muted">منذ <?php echo e($post->created_at->diffForHumans()); ?></small>
                        </td>
                        <td>
                            <?php if($post->reports->count() > 0): ?>
                                <span class="badge badge-danger">
                                    <?php echo e($post->reports->count()); ?> بلاغات
                                </span>
                                <a href="<?php echo e(route('reports.index', ['post_id' => $post->id])); ?>"
                                    class="btn btn-warning btn-sm">
                                    عرض البلاغات
                                </a>
                            <?php else: ?>
                                <span class="badge badge-success">لا توجد بلاغات</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge badge-info"><?php echo e($post->comments->count()); ?> تعليقات</span>
                        </td>
                        <td>
                            <span class="badge badge-primary"><?php echo e($post->likes->count()); ?> إعجابات</span>
                        </td>
                        <td>
                            <button class="btn btn-success" data-toggle="modal"
                                data-target="#editPostModal<?php echo e($post->id); ?>">تعديل</button>
                            <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST"
                                style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" onclick="return confirm('هل أنت متأكد؟')">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="text-center">لا توجد منشورات</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>


        <div class="mt-3">
            <?php echo e($posts->links()); ?>

        </div>
    </div>

    <!-- Add Post Modal -->
    <div class="modal fade" id="addPostModal" tabindex="-1" aria-labelledby="addPostModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <?php echo $__env->make('dashboard.posts.form', ['post' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/posts/index.blade.php ENDPATH**/ ?>