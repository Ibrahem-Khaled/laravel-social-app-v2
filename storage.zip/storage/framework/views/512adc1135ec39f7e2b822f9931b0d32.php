<div class="modal fade" id="editUserFamilyModal<?php echo e($user->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="editUserFamilyModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserFamilyModalLabel<?php echo e($user->id); ?>">تعديل مستخدم في العائلة</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('user-families.update', $user->pivot->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="role">الدور</label>
                        <input type="text" name="role" id="role" class="form-control"
                            value="<?php echo e($user->pivot->role); ?>">
                    </div>
                    <div class="form-group">
                        <label for="status">الحالة</label>
                        <select name="status" id="status" class="form-control" required>
                            <option value="pending" <?php echo e($user->pivot->status == 'pending' ? 'selected' : ''); ?>>قيد
                                الانتظار</option>
                            <option value="active" <?php echo e($user->pivot->status == 'active' ? 'selected' : ''); ?>>نشط</option>
                            <option value="inactive" <?php echo e($user->pivot->status == 'inactive' ? 'selected' : ''); ?>>غير نشط
                            </option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                    <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/families/modals/edit_user_family.blade.php ENDPATH**/ ?>