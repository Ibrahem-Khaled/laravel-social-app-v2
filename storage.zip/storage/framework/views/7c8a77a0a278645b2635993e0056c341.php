<meta name="description" content="<?php echo e($description ?? 'الوصف الافتراضي'); ?>">
<meta name="keywords" content="<?php echo e($keywords ?? 'الكلمات الافتراضية'); ?>">
<meta name="author" content="<?php echo e($author ?? 'اسم المؤلف'); ?>">
<title><?php echo e($title ?? 'العنوان الافتراضي'); ?></title><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/components/seo.blade.php ENDPATH**/ ?>