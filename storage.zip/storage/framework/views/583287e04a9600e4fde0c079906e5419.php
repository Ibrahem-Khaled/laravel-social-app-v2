

<?php $__env->startSection('content'); ?>
    <div class="container mt-4 text-right">
        <h1>إدارة البلاغات</h1>
        <a href="<?php echo e(route('reports.index', ['hidden' => true])); ?>" class="btn btn-secondary mb-3">
            عرض البلاغات المخفية
        </a>
        <!-- التقارير والإحصائيات -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">إجمالي البلاغات</h5>
                        <p class="card-text"><?php echo e($totalReports); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">عدد المنشورات المبلغ عنها</h5>
                        <p class="card-text"><?php echo e($reportedPosts); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">أكثر الأسباب شيوعًا</h5>
                        <ul class="list-group">
                            <?php $__currentLoopData = $topReasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <?php echo e($reason->reason); ?>

                                    <span class="badge badge-primary badge-pill"><?php echo e($reason->count); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- جدول البلاغات -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>المعرف</th>
                    <th>معرف المستخدم</th>
                    <th>المستخدم</th>
                    <th>المنشور</th>
                    <th>السبب</th>
                    <th>التفاصيل</th>
                    <th>تاريخ البلاغ</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($report->id); ?></td>
                        <td><?php echo e($report->user->uuid); ?></td>
                        <td><?php echo e($report->user->username); ?></td>
                        <td>
                            <!-- زر لعرض التفاصيل -->
                            <button class="btn btn-link" data-toggle="collapse"
                                data-target="#postDetails<?php echo e($report->id); ?>" aria-expanded="false"
                                aria-controls="postDetails<?php echo e($report->id); ?>">
                                <?php echo e(Str::limit($report->post->content, 50)); ?>

                            </button>

                            <!-- عرض تفاصيل المنشور -->
                            <div class="collapse mt-2" id="postDetails<?php echo e($report->id); ?>">
                                <div class="card card-body">
                                    <h5>محتوى المنشور:</h5>
                                    <p><?php echo e($report->post->content); ?></p>
                                    <?php if($report->post->media): ?>
                                        <h5 class="mt-3">الوسائط:</h5>
                                        <img src="<?php echo e($report->post->media); ?>" alt="media" class="img-fluid">
                                    <?php endif; ?>
                                    <h5 class="mt-3">الحالة:</h5>
                                    <p><?php echo e($report->post->status); ?></p>
                                    <h5 class="mt-3">تم النشر منذ:</h5>
                                    <p><?php echo e($report->post->created_at->diffForHumans()); ?></p>
                                </div>
                            </div>
                        </td>
                        <td><?php echo e($report->reason); ?></td>
                        <td><?php echo e($report->details ?? 'لا توجد تفاصيل'); ?></td>
                        <td><?php echo e($report->created_at->diffForHumans()); ?></td>
                        <td>
                            <?php if($report->is_hidden): ?>
                                <span class="badge badge-secondary">مخفي</span>
                                <form action="<?php echo e(route('reports.toggleVisibility', $report->id)); ?>" method="POST"
                                    style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button class="btn btn-warning btn-sm">إظهار</button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('reports.toggleVisibility', $report->id)); ?>" method="POST"
                                    style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button class="btn btn-danger btn-sm">إخفاء</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">لا توجد بلاغات</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3">
            <?php echo e($reports->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/posts/reports.blade.php ENDPATH**/ ?>