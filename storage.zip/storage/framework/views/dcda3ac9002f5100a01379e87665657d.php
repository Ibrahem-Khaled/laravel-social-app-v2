

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>مستخدمي الوكالة</h1>

        <!-- تفاصيل الوكالة الحالية -->
        <div class="card mb-4">
            <div class="card-header">
                <h2>تفاصيل الوكالة</h2>
            </div>
            <div class="card-body">
                <p><strong>اسم الوكالة:</strong> <?php echo e($agency->name); ?></p>
                <p><strong>وصف الوكالة:</strong> <?php echo e($agency->description); ?></p>
                <p><strong>حالة الوكالة:</strong> <?php echo e($agency->status); ?></p>
            </div>
        </div>

        <!-- زر إنشاء مستخدم جديد -->
        <button type="button" class="btn btn-primary mb-3" data-toggle="modal" data-target="#agencyUserModal">
            إنشاء مستخدم جديد
        </button>

        <!-- جدول عرض المستخدمين -->
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>الوكالة</th>
                    <th>المستخدم</th>
                    <th>الدور</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $agency->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agencyUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($agencyUser->id); ?></td>
                        <td><?php echo e($agencyUser->agency->name); ?></td>
                        <td><?php echo e($agencyUser->user->name); ?></td>
                        <td><?php echo e($agencyUser->role); ?></td>
                        <td><?php echo e($agencyUser->status); ?></td>
                        <td>
                            <!-- زر التعديل -->
                            <button type="button" class="btn btn-warning btn-sm" data-toggle="modal"
                                data-target="#agencyUserModal" data-id="<?php echo e($agencyUser->id); ?>"
                                data-agency-id="<?php echo e($agencyUser->agency_id); ?>" data-user-id="<?php echo e($agencyUser->user_id); ?>"
                                data-role="<?php echo e($agencyUser->role); ?>" data-status="<?php echo e($agencyUser->status); ?>">
                                تعديل
                            </button>
                            <!-- زر الحذف -->
                            <form action="<?php echo e(route('agency-users.destroy', $agencyUser)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Modal لإضافة/تعديل مستخدم -->
    <div class="modal fade" id="agencyUserModal" tabindex="-1" aria-labelledby="agencyUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="agencyUserModalLabel">إنشاء/تعديل مستخدم الوكالة</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="إغلاق">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="agencyUserForm" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="agencyUserId" name="id">
                        <div class="form-group">
                            <label for="agency_id">الوكالة</label>
                            <select name="agency_id" id="agency_id" class="form-control" required>
                                <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($agency->id); ?>"><?php echo e($agency->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="user_id">المستخدم</label>
                            <select name="user_id" id="user_id" class="form-control" required>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="role">الدور</label>
                            <input type="text" name="role" id="role" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="status">الحالة</label>
                            <select name="status" id="status" class="form-control" required>
                                <option value="pending">قيد الانتظار</option>
                                <option value="active">نشط</option>
                                <option value="inactive">غير نشط</option>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                            <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#agencyUserModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                var id = button.data('id');

                if (id) {
                    // تعديل مستخدم موجود
                    var agencyId = button.data('agency-id');
                    var userId = button.data('user-id');
                    var role = button.data('role');
                    var status = button.data('status');

                    $('#agencyUserId').val(id);
                    $('#agency_id').val(agencyId);
                    $('#user_id').val(userId);
                    $('#role').val(role);
                    $('#status').val(status);

                    $('#agencyUserModalLabel').text('تعديل مستخدم الوكالة');
                    $('#agencyUserForm').attr('action', '<?php echo e(url('agency-users')); ?>/' + id);
                    $('#agencyUserForm').append('<input type="hidden" name="_method" value="PUT">');
                } else {
                    // إنشاء مستخدم جديد
                    $('#agencyUserModalLabel').text('إنشاء مستخدم جديد');
                    $('#agencyUserForm').attr('action', '<?php echo e(route('agency-users.store')); ?>');
                    $('#agencyUserForm').find('input[name="_method"]').remove();
                }
            });

            $('#agencyUserModal').on('hidden.bs.modal', function() {
                $('#agencyUserForm')[0].reset();
                $('#agencyUserId').val('');
                $('#agencyUserForm').find('input[name="_method"]').remove();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/agencies/show.blade.php ENDPATH**/ ?>