

<?php $__env->startSection('content'); ?>
    <div class="container mt-4 text-right">
        <h1>إدارة الإشعارات</h1>
        <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- التقارير -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <i class="fas fa-bell fa-3x text-primary mb-3"></i>
                        <h3><?php echo e($totalNotifications); ?></h3>
                        <p>إجمالي الإشعارات</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <i class="fas fa-eye fa-3x text-success mb-3"></i>
                        <h3><?php echo e($readNotifications); ?></h3>
                        <p>الإشعارات المقروءة</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <i class="fas fa-eye-slash fa-3x text-danger mb-3"></i>
                        <h3><?php echo e($unreadNotifications); ?></h3>
                        <p>الإشعارات غير المقروءة</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <i class="fas fa-users fa-3x text-info mb-3"></i>
                        <h3><?php echo e($uniqueUsers); ?></h3>
                        <p>المستخدمون المستلمون</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- زر فتح المودال لإضافة إشعار -->
        <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#addNotificationModal">إضافة إشعار
            جديد</button>

        <!-- المودال -->
        <div class="modal fade" id="addNotificationModal" tabindex="-1" aria-labelledby="addNotificationModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('notifications.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="addNotificationModalLabel">إضافة إشعار جديد</h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="user_id" class="form-label">المستخدم</label>
                                <select name="user_id" class="form-control" required>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="type" class="form-label">نوع الإشعار</label>
                                <input type="text" name="type" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="message" class="form-label">نص الإشعار</label>
                                <textarea name="message" class="form-control" rows="3" required></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">إضافة</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- جدول الإشعارات -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll"></th>
                    <th>المستخدم</th>
                    <th>النوع</th>
                    <th>الإشعار</th>
                    <th>الحالة</th>
                    <th>تاريخ الإرسال</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <input type="checkbox" name="notification_ids[]" value="<?php echo e($notification->id); ?>">
                        </td>
                        <td><?php echo e($notification->user->name); ?></td>
                        <td><?php echo e($notification->type); ?></td>
                        <td><?php echo e($notification->message); ?></td>
                        <td>
                            <?php if($notification->is_read): ?>
                                <span class="badge bg-success">مقروء</span>
                            <?php else: ?>
                                <span class="badge bg-danger">غير مقروء</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($notification->created_at->diffForHumans()); ?></td>
                        <td>
                            <?php if(!$notification->is_read): ?>
                                <form action="<?php echo e(route('notifications.markAsRead', $notification->id)); ?>" method="POST"
                                    style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-sm btn-primary">تعليم كمقروء</button>
                                </form>
                            <?php endif; ?>
                            <form action="<?php echo e(route('notifications.delete', $notification->id)); ?>" method="POST"
                                style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">حذف</button>
                            </form>

                            <button class="btn btn-sm btn-warning" data-toggle="modal"
                                data-target="#editNotificationModal<?php echo e($notification->id); ?>">تعديل</button>
                            <div class="modal fade" id="editNotificationModal<?php echo e($notification->id); ?>" tabindex="-1"
                                aria-labelledby="editNotificationModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('notifications.update', $notification->id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editNotificationModalLabel">تعديل الإشعار
                                                </h5>
                                                <button type="button" class="btn-close" data-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="user_id" class="form-label">المستخدم</label>
                                                    <select name="user_id" class="form-control" required>
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($user->id); ?>"
                                                                <?php echo e($notification->user_id == $user->id ? 'selected' : ''); ?>>
                                                                <?php echo e($user->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="type" class="form-label">نوع الإشعار</label>
                                                    <input type="text" name="type" class="form-control"
                                                        value="<?php echo e($notification->type); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="message" class="form-label">نص الإشعار</label>
                                                    <textarea name="message" class="form-control" rows="3" required><?php echo e($notification->message); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">إلغاء</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">لا توجد إشعارات</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3">
            <?php echo e($notifications->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/notifications/index.blade.php ENDPATH**/ ?>