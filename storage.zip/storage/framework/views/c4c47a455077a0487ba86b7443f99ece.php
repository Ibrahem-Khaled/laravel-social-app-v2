<form action="<?php echo e(route('messages.sendAnonymous')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="modal-header">
        <h5 class="modal-title" id="sendMessageModalLabel">إرسال رسالة جديدة</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <div class="mb-3">
            <label for="message" class="form-label">نص الرسالة</label>
            <textarea name="message" class="form-control" required></textarea>
        </div>
        
        <div class="mb-3">
            <label for="recipients" class="form-label">المستلمون</label>
            <button type="button" id="selectAllUsers" class="btn btn-sm btn-secondary mb-2">تحديد الكل</button>
            <select name="recipients[]" id="recipients" class="form-control" multiple>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> - <?php echo e($user->email); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="filters" class="form-label">التصفية (اختياري)</label>
            <select name="filters[]" class="form-control" multiple>
                <option value="male">ذكور</option>
                <option value="female">إناث</option>
                <option value="egypt">مستخدمون من مصر</option>
            </select>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-primary">إرسال</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
    </div>
</form>

<script>
    document.getElementById('selectAllUsers').addEventListener('click', function() {
        const selectBox = document.getElementById('recipients');
        for (let i = 0; i < selectBox.options.length; i++) {
            selectBox.options[i].selected = true;
        }
    });
</script>
<?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/messages/form.blade.php ENDPATH**/ ?>