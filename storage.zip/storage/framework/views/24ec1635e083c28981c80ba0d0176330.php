

<?php $__env->startSection('content'); ?>
    <h1>العائلات</h1>
    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#addFamilyModal">إنشاء عائلة</button>
    <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table">
        <thead>
            <tr>
                <th>بيانات صاحب العائلة</th>
                <th>الاسم</th>
                <th>الوصف</th>
                <th>الصورة</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($family->user->name); ?> -- <?php echo e($family->user->email); ?> -- <?php echo e($family->user->phone); ?></td>
                    <td><?php echo e($family->name); ?></td>
                    <td><?php echo e($family->description); ?></td>
                    <td>
                        <?php if($family->image): ?>
                            <img src="<?php echo e(asset('storage/' . $family->image)); ?>" alt="<?php echo e($family->name); ?>" width="100">
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('families.show', $family->id)); ?>" class="btn btn-info">عرض</a>
                        <button class="btn btn-warning" data-toggle="modal"
                            data-target="#editFamilyModal<?php echo e($family->id); ?>">تعديل</button>
                        <form action="<?php echo e(route('families.destroy', $family->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">حذف</button>
                        </form>
                    </td>
                </tr>
                <!-- Modal لتعديل العائلة -->
                <?php echo $__env->make('dashboard.families.modals.edit_family', ['family' => $family], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Modal لإضافة عائلة -->
    <?php echo $__env->make('dashboard.families.modals.add_family', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/families/index.blade.php ENDPATH**/ ?>