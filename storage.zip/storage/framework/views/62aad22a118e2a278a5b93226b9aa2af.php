<thead>
    <tr>
        <th>المعرف</th>
        <th>الحالة</th>
        <th>الاسم</th>
        <th>اسم المستخدم</th>
        <th>البريد الإلكتروني</th>
        <th>الدولة</th>
        <th>النقاط </th>
        <th>الإجراءات</th>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->uuid); ?></td>
            <td><?php echo e($user->status); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->username); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->country ?? 'غير محددة'); ?></td>
            <td><?php echo e($user->coins ?? 'غير محددة'); ?></td>
            <td>
                <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-info btn-sm">عرض الملف الشخصي</a>
                <button class="btn btn-success" data-toggle="modal"
                    data-target="#editUserModal<?php echo e($user->id); ?>">تعديل</button>
                <button class="btn btn-primary" data-toggle="modal"
                    data-target="#manageCoinsModal<?php echo e($user->id); ?>">إدارة النقاط</button>
                <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" style="display: inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" onclick="return confirm('هل أنت متأكد؟')">حذف</button>
                </form>
                <form action="<?php echo e(route('users.toggleBan', $user->id)); ?>" method="POST" style="display: inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button class="btn btn-warning" onclick="return confirm('هل أنت متأكد؟')">
                        <?php echo e($user->status == 'banned' ? 'إلغاء الحظر' : 'حظر'); ?>

                    </button>
                </form>
            </td>
        </tr>

        <!-- Manage Coins Modal -->
        <div class="modal fade" id="manageCoinsModal<?php echo e($user->id); ?>" tabindex="-1"
            aria-labelledby="manageCoinsLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('users.manageCoins', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">إدارة النقاط - <?php echo e($user->name); ?></h5>
                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="coins" class="form-label">عدد النقاط</label>
                                <input type="number" name="coins" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="action" class="form-label">الإجراء</label>
                                <select name="action" class="form-control" required>
                                    <option value="add">إضافة نقاط</option>
                                    <option value="subtract">سحب نقاط</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">تنفيذ</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <!-- Edit User Modal -->
        <div class="modal fade" id="editUserModal<?php echo e($user->id); ?>" tabindex="-1"
            aria-labelledby="editUserModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <?php echo $__env->make('dashboard.users.form', ['user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/users/table.blade.php ENDPATH**/ ?>