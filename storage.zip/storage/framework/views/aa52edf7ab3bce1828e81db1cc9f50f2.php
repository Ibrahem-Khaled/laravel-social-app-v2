

<?php $__env->startSection('content'); ?>
    <div class="container mt-4 text-right">
        <h1>طلبات التوثيق</h1>
        <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>المستخدم</th>
                    <th>الاسم الرباعي</th>
                    <th>الوجه الأمامي</th>
                    <th>الوجه الخلفي</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $verificationRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a href="<?php echo e(route('users.show', $request->user->id)); ?>"><?php echo e($request->user->name); ?></a> </td>
                        <td><?php echo e($request->full_name); ?></td>
                        <td><a href="<?php echo e(asset('storage/' . $request->front_id_image)); ?>" target="_blank">عرض</a></td>
                        <td><a href="<?php echo e(asset('storage/' . $request->back_id_image)); ?>" target="_blank">عرض</a></td>
                        <td><?php echo e($request->status); ?></td>
                        <td>
                            <?php if($request->status == 'pending'): ?>
                                <form action="<?php echo e(route('verification.approve', $request->id)); ?>" method="POST"
                                    style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-success btn-sm">قبول</button>
                                </form>
                                <button class="btn btn-danger btn-sm" data-toggle="modal"
                                    data-target="#rejectModal<?php echo e($request->id); ?>">رفض</button>
                                <!-- رفض -->
                                <div class="modal fade" id="rejectModal<?php echo e($request->id); ?>" tabindex="-1"
                                    aria-labelledby="rejectModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?php echo e(route('verification.reject', $request->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">سبب الرفض</h5>
                                                    <button type="button" class="btn-close" data-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <textarea name="rejection_reason" class="form-control" rows="3" required></textarea>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-danger">رفض</button>
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">إلغاء</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">لا توجد طلبات توثيق</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="mt-3">
            <?php echo e($verificationRequests->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/verifications/index.blade.php ENDPATH**/ ?>