

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="mb-4">البثوث المباشرة</h1>

        <!-- زر فتح المودال -->
        <button type="button" class="btn btn-primary mb-3" data-toggle="modal" data-target="#liveStreamingModal">
            إضافة بث مباشر
        </button>

        <!-- مودال إضافة / تعديل البث -->
        <div class="modal fade" id="liveStreamingModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalLabel">
                            <?php echo e(isset($liveStreaming) ? 'تعديل البث' : 'إضافة بث مباشر'); ?></h5>
                        <button type="button" class="btn-close" data-dismiss="modal" aria-label="إغلاق"></button>
                    </div>
                    <div class="modal-body">
                        <form id="liveStreamingForm"
                            action="<?php echo e(isset($liveStreaming) ? route('live_streamings.update', $liveStreaming->id) : route('live_streamings.store')); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($liveStreaming)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>

                            <div class="mb-3">
                                <label for="user_id" class="form-label">معرف المستخدم</label>
                                <select name="user_id" class="form-control" required>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"
                                            <?php echo e(isset($liveStreaming) && $liveStreaming->user_id == $user->id ? 'selected' : ''); ?>>
                                            <?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="agency_id" class="form-label">معرف الوكالة</label>
                                <select name="agency_id" class="form-control">
                                    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($agency->id); ?>"
                                            <?php echo e(isset($liveStreaming) && $liveStreaming->agency_id == $agency->id ? 'selected' : ''); ?>>
                                            <?php echo e($agency->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="title" class="form-label">العنوان</label>
                                <input type="text" name="title" class="form-control"
                                    value="<?php echo e(isset($liveStreaming) ? $liveStreaming->title : ''); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">الوصف</label>
                                <textarea name="description" class="form-control"><?php echo e(isset($liveStreaming) ? $liveStreaming->description : ''); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">الحالة</label>
                                <select name="status" class="form-control" required>
                                    <option value="pending"
                                        <?php echo e(isset($liveStreaming) && $liveStreaming->status == 'pending' ? 'selected' : ''); ?>>
                                        معلق</option>
                                    <option value="live"
                                        <?php echo e(isset($liveStreaming) && $liveStreaming->status == 'live' ? 'selected' : ''); ?>>
                                        مباشر</option>
                                    <option value="completed"
                                        <?php echo e(isset($liveStreaming) && $liveStreaming->status == 'completed' ? 'selected' : ''); ?>>
                                        مكتمل</option>
                                    <option value="cancelled"
                                        <?php echo e(isset($liveStreaming) && $liveStreaming->status == 'cancelled' ? 'selected' : ''); ?>>
                                        ملغي</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="scheduled_at" class="form-label">الجدولة</label>
                                <input type="datetime-local" name="scheduled_at" class="form-control"
                                    value="<?php echo e(isset($liveStreaming) && $liveStreaming->scheduled_at ? $liveStreaming->scheduled_at->format('Y-m-d\TH:i') : ''); ?>">
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                                <button type="submit"
                                    class="btn btn-primary"><?php echo e(isset($liveStreaming) ? 'تحديث' : 'إضافة'); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- قائمة البثوث المباشرة -->
        <h2 class="mt-5">قائمة البثوث</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>المعرف</th>
                    <th>العنوان</th>
                    <th>الحالة</th>
                    <th>معرف البث</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $liveStreamings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liveStreaming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($liveStreaming->id); ?></td>
                        <td><?php echo e($liveStreaming->title); ?></td>
                        <td><?php echo e($liveStreaming->status); ?></td>
                        <td><?php echo e($liveStreaming->live_streaming_id); ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#liveStreamingModal"
                                onclick="editLiveStreaming(<?php echo e(json_encode($liveStreaming)); ?>)">تعديل</button>
                            <form action="<?php echo e(route('live_streamings.destroy', $liveStreaming->id)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        function editLiveStreaming(liveStreaming) {
            document.querySelector('[name=user_id]').value = liveStreaming.user_id;
            document.querySelector('[name=agency_id]').value = liveStreaming.agency_id;
            document.querySelector('[name=title]').value = liveStreaming.title;
            document.querySelector('[name=description]').value = liveStreaming.description;
            document.querySelector('[name=status]').value = liveStreaming.status;
            document.querySelector('[name=scheduled_at]').value = liveStreaming.scheduled_at ? liveStreaming.scheduled_at
                .replace(' ', 'T') : '';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/live_streamings/index.blade.php ENDPATH**/ ?>