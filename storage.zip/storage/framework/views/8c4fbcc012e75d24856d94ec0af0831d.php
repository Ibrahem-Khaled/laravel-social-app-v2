

<?php $__env->startSection('content'); ?>
    <h1>تفاصيل العائلة: <?php echo e($family->name); ?></h1>
    <p>الوصف: <?php echo e($family->description); ?></p>
    <button type="button" class="btn btn-primary mb-3" data-toggle="modal" data-target="#addUserFamilyModal">
        إضافة مستخدم
    </button>
    <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2>الأعضاء</h2>
    <table class="table">
        <thead>
            <tr>
                <th>الاسم</th>
                <th>الدور</th>
                <th>الحالة</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $family->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->pivot->role); ?></td>
                    <td><?php echo e($user->pivot->status); ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal"
                            data-target="#editUserFamilyModal<?php echo e($user->id); ?>">تعديل</button>
                        <form action="<?php echo e(route('user-families.destroy', $user->pivot->id)); ?>" method="POST"
                            style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">حذف</button>
                        </form>
                    </td>
                </tr>
                <!-- Modal لتعديل المستخدم -->
                <?php echo $__env->make('dashboard.families.modals.edit_user_family', [
                    'user' => $user,
                    'family' => $family,
                    'users' => $users,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <!-- Modal لإضافة مستخدم -->
    <?php echo $__env->make('dashboard.families.modals.add_user_family', ['family' => $family, 'users' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/families/show.blade.php ENDPATH**/ ?>