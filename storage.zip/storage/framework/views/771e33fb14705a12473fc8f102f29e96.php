

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1 class="text-center">لوحة التحكم</h1>

        <!-- الإحصائيات الإجمالية -->
        <div class="row mt-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-3x mb-2"></i>
                        <h3><?php echo e($totalUsers); ?></h3>
                        <p>إجمالي المستخدمين</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-user-check fa-3x mb-2"></i>
                        <h3><?php echo e($activeUsers); ?></h3>
                        <p>المستخدمين النشطين</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-dark">
                    <div class="card-body text-center">
                        <i class="fas fa-user-times fa-3x mb-2"></i>
                        <h3><?php echo e($inactiveUsers); ?></h3>
                        <p>المستخدمين الغير نشطين</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-id-card fa-3x mb-2"></i>
                        <h3><?php echo e($totalVerificationRequests); ?></h3>
                        <p>طلبات التحقق</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- الإحصائيات الأخرى -->
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-newspaper fa-3x mb-2"></i>
                        <h3><?php echo e($totalPosts); ?></h3>
                        <p>إجمالي المنشورات</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-secondary text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-comments fa-3x mb-2"></i>
                        <h3><?php echo e($totalComments); ?></h3>
                        <p>إجمالي التعليقات</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-dark text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-envelope fa-3x mb-2"></i>
                        <h3><?php echo e($totalMessages); ?></h3>
                        <p>إجمالي الرسائل</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <i class="fas fa-exclamation-triangle fa-3x text-danger mb-2"></i>
                        <h3 class="text-danger"><?php echo e($totalReports); ?></h3>
                        <p>إجمالي البلاغات</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <i class="fas fa-gift fa-3x text-success mb-2"></i>
                        <h3 class="text-success"><?php echo e($totalGifts); ?></h3>
                        <p>إجمالي الهدايا</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- الإحصائيات الإضافية -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <i class="fas fa-thumbs-up fa-3x text-primary mb-2"></i>
                        <h3 class="text-primary"><?php echo e($totalLikes); ?></h3>
                        <p>إجمالي الإعجابات</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <i class="fas fa-share-alt fa-3x text-info mb-2"></i>
                        <h3 class="text-info"><?php echo e($totalShares); ?></h3>
                        <p>إجمالي المشاركات</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- المنشورات الأكثر تفاعلاً -->
        <div class="row mt-5">
            <div class="col-md-12">
                <h4 class="text-center">أكثر المنشورات تفاعلاً</h4>
                <ul class="list-group">
                    <?php $__currentLoopData = $topPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>
                                <?php echo e(Str::limit($post->content, 50)); ?>

                                <span class="text-muted">(<?php echo e($post?->created_at?->diffForHumans()); ?>)</span>
                            </span>
                            <span>
                                <span class="badge bg-info">تعليقات: <?php echo e($post->comments_count); ?></span>
                                <span class="badge bg-primary">إعجابات: <?php echo e($post->likes_count); ?></span>
                                <span class="badge bg-warning">مشاركات: <?php echo e($post->shares_count); ?></span>
                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\PHP\Laravel\social-media-app-v2\resources\views/dashboard/index.blade.php ENDPATH**/ ?>